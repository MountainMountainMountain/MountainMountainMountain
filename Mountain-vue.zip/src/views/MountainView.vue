<template>
    <div>
        <RouterView />
    </div>
</template>

<script setup>
import MainNavBar from '@/components/common/MainNavBar.vue';
</script>

<style scoped>

</style>