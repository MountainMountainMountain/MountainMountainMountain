<template>
    <div>
        <RouterView />
    </div>
</template>

<script setup>
import MainLoginNavBar from '@/components/common/MainLoginNavBar.vue';
</script>

<style scoped></style>