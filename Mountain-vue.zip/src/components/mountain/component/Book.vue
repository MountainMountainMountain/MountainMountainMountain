<template>
    <div>
        <Weather />
        <h1>book</h1>
    </div>
</template>

<script setup>
import Weather from '@/components/mountain/component/Weather.vue';
</script>

<style scoped></style>