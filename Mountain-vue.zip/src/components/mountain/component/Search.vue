<template>
    <div class="container">
    <div class="input-group mb-3">
      <span class="input-group-text"></span>
      <input
        type="text"
        class="form-control"
        placeholder="산을 입력하세요"
      />
      <button type="button" class="btn btn-primary"><i class="fas fa-search" style="color: blue" ></i></button>
      <button class="btn btn-primary" ><i class="fas fa-search" style="color: red" ></i></button>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';



</script>

<style scoped>

</style>