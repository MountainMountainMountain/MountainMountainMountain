<template>
    <div>
        <MyState /> 
    </div>
</template>

<script setup>
import MyState from "../component/MyState.vue"
import MainLoginNavBar from '@/components/common/MainLoginNavBar.vue';
</script>

<style scoped>
/* .container {

} */
</style>