<template>
    <div>
        <SignUp />
    </div>
</template>

<script setup>
import SignUp from "../component/SignUp.vue"
</script>

<style scoped>

</style>