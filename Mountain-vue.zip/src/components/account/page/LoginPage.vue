<template>
    <div>
        <Login />
    </div>
</template>

<script setup>
import Login from "../component/Login.vue"
</script>

<style scoped>

</style>