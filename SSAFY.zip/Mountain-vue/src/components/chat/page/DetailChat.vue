<template>
    <div>
        <h1>detailchat</h1>
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>