<template>
    <div>
        <MyState /> 
    </div>
</template>

<script setup>
import MyState from "../component/MyState.vue"
</script>

<style scoped>
</style>