<template>
    <div>
        <RouterView />
    </div>
</template>

<script setup>

</script>

<style scoped></style>